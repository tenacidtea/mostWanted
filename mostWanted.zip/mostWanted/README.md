Most Wanted Assignment
==============================

Read this entire README and ask any questions you have before starting to code.

Before starting this project, read the instructions.pdf included in the repository!

Also, after cloning the repo, run ‘npm install’


Authorities on the Matter
-------

* **Nick**
* **Andrew**
* **Adam**

Please contact one of the instructors listed above if you have any questions about this assignment. If they are not available, ask whichever instructor(s) is.


Warning
----------------

This software is for educational and instructional use only.
devCodeCamp will not be held liable if you use this code.
Any student(s) found using someone else's code or sharing code for this assignment will receive a score of zero.


Bugs & Additions
----------------

Have a bug or want to add something? Please create an issue or a pull request right here.
https://github.com/devCodeCamp/dcc-py-twitbot


Copyright and License
---------------------

Copyright (c) 2017 devCodeCamp. All Rights Reserved.

The above copyright notice and and the following conditions shall be included in all
copies or substantial portions of this software (repository).

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
